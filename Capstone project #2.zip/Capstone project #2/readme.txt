Completed Code in the Learning Environment

#first part of project going over species in danger
import codecademylib
import pandas as pd
from matplotlib import pyplot as plt
species = pd.read_csv('species_info.csv')
print species.head()
#number of different species
species_count = species.scientific_name.nunique()
print species_count
#number of categories
species_type = species.category.unique()
print species_type
#number of status'
conservation_statuses = species.conservation_status.unique()
print conservation_statuses


conservation_counts = species.groupby('conservation_status').scientific_name.nunique().reset_index()
species.fillna('No Intervention', inplace = True)
conservation_counts_fixed = species.groupby('conservation_status').scientific_name.nunique().reset_index()
print conservation_counts_fixed


#chart code for animals in danger
protection_counts = species.groupby('conservation_status')\
    .scientific_name.nunique().reset_index()\
    .sort_values(by='scientific_name')
plt.figure(figsize=(10, 4))
ax = plt.subplot()
plt.bar(range(len(protection_counts)),protection_counts.scientific_name.values)
ax.set_xticks(range(len(protection_counts)))
ax.set_xticklabels(protection_counts.conservation_status.values)
plt.ylabel('Number of Species')
plt.title('Conservation Status by Species')
labels = [e.get_text() for e in ax.get_xticklabels()]
plt.show()
#6/15
species['is_protected'] = species.conservation_status != 'No Intervention'
category_counts = species.groupby(['category', 'is_protected']).scientific_name.nunique().reset_index()
print category_counts.head()
category_pivot = category_counts.pivot(columns='is_protected',
                      index='category',
                      values='scientific_name')\
                      .reset_index()
print category_pivot
#7/15  
category_pivot.columns = ['category', 'not_protected', 'protected']
category_pivot['percent_protected'] = category_pivot.protected / (category_pivot.protected + category_pivot.not_protected)
print category_pivot
#8/15 chi square test
contingency = [[30, 146],
              [75, 413]]

pval = chi2_contingency(contingency)[1]
print(pval)
# No significant difference because pval > 0.05

contingency_reptile_mammal = [[30, 146],
                              [5, 73]]

pval_reptile_mammal = chi2_contingency(contingency_reptile_mammal)[1]
print(pval_reptile_mammal)
# Significant difference! pval_reptile_mammal < 0.05


#part two going over sheep species observations
import codecademylib
import pandas as pd
from matplotlib import pyplot as plt
species = pd.read_csv('species_info.csv')
species.fillna('No Intervention', inplace = True)
species['is_protected'] = species.conservation_status != 'No Intervention'
observations = pd.read_csv('observations.csv')
print observations.head()
#new sheep column that is true/false for sheep
species['is_sheep'] = species.common_names.apply(lambda x: 'Sheep' in x)
#select all rows containing sheep
species_is_sheep = species[species.is_sheep]
#inspect the sheep rows
print species_is_sheep
#weed out plants
sheep_species = species[(species.is_sheep) & (species.category == 'Mammal')]
#see final sheep results
print sheep_species
#merge sheep species and observations
sheep_observations = observations.merge(sheep_species)
#inspect few rows
print sheep_observations.head()
#total sheep sightings at each park for all 3 species
obs_by_park = sheep_observations.groupby('park_name').observations.sum().reset_index()
#see total number of sheep observed over past 7 days
print obs_by_park


#chart codes for sheep observations
plt.figure(figsize=(16, 4))
ax = plt.subplot()
plt.bar(range(len(obs_by_park)),
        obs_by_park.observations.values)
ax.set_xticks(range(len(obs_by_park)))
ax.set_xticklabels(obs_by_park.park_name.values)
plt.ylabel('Number of Observations')
plt.title('Observations of Sheep per Week')
plt.show()

#sample size determination for hoof and mouth disease
baseline = 15

minimum_detectable_effect = 100*5./15

sample_size_per_variant = 870

yellowstone_weeks_observing = sample_size_per_variant/507.

bryce_weeks_observing = sample_size_per_variant/250.
